name = ["Carlos","Daniel","Alex","Rodrigo","Andres"]
print(name)
name.clear()
print(name)

