fruits = ["apple","pear","strawbwrry","grape","mango"]
fruits.append("watermelon")
print(fruits)
fruits.insert(1,"banana")
print(fruits)
fruits.remove("grape")
print(fruits)
fruits.pop()
print(fruits)



