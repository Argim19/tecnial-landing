person = {
    "name":"Ana",
    "age":25,
    "city":"Bogota"
}

print(person["name"])
print(person.get("age"))
print(person.get("celphone","not exist"))
