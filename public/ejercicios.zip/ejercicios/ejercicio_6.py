person = {
    "name":"Ana",
    "age":25,
    "city":"Bogota"
}

person["profesion"] = "student"
print(person)
person["age"] = 22
print(person)
date_deleted = person.pop("city")
print(date_deleted)
print(person)

