elements = {
    "ID":256,
    "name":"jose",
    "height":1.75
}

delete = elements.popitem()
print(delete)
print(elements)