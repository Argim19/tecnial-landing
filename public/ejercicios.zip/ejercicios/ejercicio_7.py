products = {
    "Bread":1500,
    "Milk":3200,
    "Agg":9000,
}

data = list(products.keys())
print(data)
data_1 = list(products.values())
print(data_1)
data_2 = list(products.items())
print(data_2[2])
print(data_2[2][0])
print(data_2[2][1])
