num = [4,2,7,2,9,1,2]
print(num)
num.sort()
print(num)
num.reverse()
print(num)
conteo = num.count(2)
print(conteo)
print(num.index(7))