students = [
    {
        "name":"Luis",
        "nota":4.5
    },
    {
        "name":"Marta",
        "nota":3.8
    },
    {
        "name":"carlos",
        "nota":4.2
    }
]

notas = []

for i in students:
    
    print(i["name"])

for i in students:
    notas.append(i["nota"])
    



for i in students:
    if i["nota"] > 4.0: 
        print(i["name"],i["nota"])



suma = (notas[0]+ notas[1] + notas[2]) / len(notas)
print(suma)        