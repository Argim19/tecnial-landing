price = float(input("enter the price:"))
quantity = int(input("enter the quantity:"))

total = price * quantity

if total >= 10000:
    discount = 0.20
else:
    discount = 0

final_price = total - (total * discount)

print("total without discount:",total)
print("descuento aplicado:",discount * 100,"%")
print("total con descuento:",final_price)